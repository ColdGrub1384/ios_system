//
//  bc_ios.h
//  bc_ios
//
//  Created by Nicolas Holzschuch on 04/11/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for bc_ios.
FOUNDATION_EXPORT double bc_iosVersionNumber;

//! Project version string for bc_ios.
FOUNDATION_EXPORT const unsigned char bc_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <bc_ios/PublicHeader.h>


