//
//  clang.h
//  clang
//
//  Created by Nicolas Holzschuch on 03/05/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for clang.
FOUNDATION_EXPORT double clangVersionNumber;

//! Project version string for clang.
FOUNDATION_EXPORT const unsigned char clangVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <clang/PublicHeader.h>


