//
//  files.h
//  files
//
//  Created by Nicolas Holzschuch on 25/03/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for files.
FOUNDATION_EXPORT double filesVersionNumber;

//! Project version string for files.
FOUNDATION_EXPORT const unsigned char filesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <files/PublicHeader.h>


