//
//  lua_ios.h
//  lua_ios
//
//  Created by Nicolas Holzschuch on 04/12/2017.
//  Copyright © 2017 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for lua_ios.
FOUNDATION_EXPORT double lua_iosVersionNumber;

//! Project version string for lua_ios.
FOUNDATION_EXPORT const unsigned char lua_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <lua_ios/PublicHeader.h>


