//
//  awk.h
//  awk
//
//  Created by Nicolas Holzschuch on 25/03/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for awk.
FOUNDATION_EXPORT double awkVersionNumber;

//! Project version string for awk.
FOUNDATION_EXPORT const unsigned char awkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <awk/PublicHeader.h>


