//
//  tar.h
//  tar
//
//  Created by Nicolas Holzschuch on 25/03/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for tar.
FOUNDATION_EXPORT double tarVersionNumber;

//! Project version string for tar.
FOUNDATION_EXPORT const unsigned char tarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <tar/PublicHeader.h>


