//
//  nm.h
//  nm
//
//  Created by Nicolas Holzschuch on 03/05/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for nm.
FOUNDATION_EXPORT double nmVersionNumber;

//! Project version string for nm.
FOUNDATION_EXPORT const unsigned char nmVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <nm/PublicHeader.h>


