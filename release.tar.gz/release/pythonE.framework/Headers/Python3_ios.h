//
//  Python3_ios.h
//  Python3_ios
//
//  Created by Nicolas Holzschuch on 16/12/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Python3_ios.
FOUNDATION_EXPORT double Python3_iosVersionNumber;

//! Project version string for Python3_ios.
FOUNDATION_EXPORT const unsigned char Python3_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Python3_ios/PublicHeader.h>
extern int python_main(int argc, char **argv);

