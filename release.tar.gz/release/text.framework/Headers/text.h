//
//  text.h
//  text
//
//  Created by Nicolas Holzschuch on 25/03/2018.
//  Copyright © 2018 Nicolas Holzschuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for text.
FOUNDATION_EXPORT double textVersionNumber;

//! Project version string for text.
FOUNDATION_EXPORT const unsigned char textVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <text/PublicHeader.h>


